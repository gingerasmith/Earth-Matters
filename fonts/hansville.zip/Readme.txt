NOTE: This demo font is for PERSONAL USE ONLY! But any donation are very appreciated. 

Please contact me before any commercial use.
My fonts for free use allowed only in personal project , non-profit and charity use.
If you make money from using my fonts, Please purchase a commercial license

Link to purchase FULL VERSION and COMERCIAL LICENSE: 
https://fontbundles.net/naharstd

Paypal account for donation : 
https://paypal.me/nahar17

Thank you.

Best
Naharstd